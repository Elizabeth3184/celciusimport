#by: Elizabeth Porteur
celsius = float(input("Enter the Temperate in Celsius :"))
fahrenheit = (celsius * 1.8) + 32

print( "%.2f C = %.2f F" %( celsius,fahrenheit ))
